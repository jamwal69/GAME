from enum import Enum


class HandSide(Enum):
    RIGHT = 0
    LEFT = 1
